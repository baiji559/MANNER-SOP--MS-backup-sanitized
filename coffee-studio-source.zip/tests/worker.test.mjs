import assert from 'node:assert/strict';
import worker from '../worker/index.js';

const originalFetch = globalThis.fetch;
let upstreamRequests = [];
let inviteAllowed = false;

globalThis.fetch = async (request, init) => {
  const upstreamRequest = request instanceof Request ? request : new Request(request, init);
  upstreamRequests.push(upstreamRequest);

  if (upstreamRequest.url.endsWith('/rest/v1/rpc/can_request_magic_link')) {
    return new Response(JSON.stringify(inviteAllowed), {
      status: 200,
      headers: {
        'content-type': 'application/json',
        'access-control-allow-origin': '*'
      }
    });
  }

  if (upstreamRequest.url.endsWith('/auth/v1/otp')) {
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    });
  }

  if (upstreamRequest.url.endsWith('/rest/v1/profiles?role=eq.owner&select=email&limit=1')) {
    return new Response(JSON.stringify([{ email: 'owner@example.com' }]), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    });
  }

  if (upstreamRequest.url.endsWith('/auth/v1/admin/generate_link')) {
    return new Response(JSON.stringify({ properties: { hashed_token: 'test-token-hash' } }), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    });
  }

  throw new Error(`Unexpected upstream request: ${upstreamRequest.url}`);
};

const authHeaders = {
  apikey: 'publishable-test-key',
  authorization: 'Bearer publishable-test-key',
  'content-type': 'application/json'
};

try {
  const rpcRequest = new Request(
    'https://coffeeindex.dpdns.org/supabase/rest/v1/rpc/can_request_magic_link',
    {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({ p_email: 'nobody@example.com' })
    }
  );
  const rpcResponse = await worker.fetch(rpcRequest, {
    ASSETS: { fetch: () => new Response('asset') }
  });

  assert.equal(upstreamRequests[0].url, 'https://your_project_ref.supabase.co/rest/v1/rpc/can_request_magic_link');
  assert.equal(upstreamRequests[0].method, 'POST');
  assert.equal(await upstreamRequests[0].clone().json().then(body => body.p_email), 'nobody@example.com');
  assert.equal(rpcResponse.status, 200);
  assert.equal(await rpcResponse.text(), 'false');
  assert.equal(rpcResponse.headers.get('access-control-allow-origin'), null);

  upstreamRequests = [];
  const assetResponse = await worker.fetch(
    new Request('https://coffeeindex.dpdns.org/app.js'),
    { ASSETS: { fetch: () => new Response('asset') } }
  );
  assert.equal(upstreamRequests.length, 0);
  assert.equal(await assetResponse.text(), 'asset');

  upstreamRequests = [];
  inviteAllowed = false;
  const blockedResponse = await worker.fetch(
    new Request('https://coffeeindex.dpdns.org/supabase/auth/v1/otp', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({ email: 'uninvited@example.com' })
    }),
    { ASSETS: { fetch: () => new Response('asset') } }
  );
  assert.equal(blockedResponse.status, 403);
  assert.equal((await blockedResponse.json()).code, 'email_not_invited');
  assert.equal(upstreamRequests.length, 1);
  assert.equal(upstreamRequests[0].url, 'https://your_project_ref.supabase.co/rest/v1/rpc/can_request_magic_link');

  upstreamRequests = [];
  inviteAllowed = true;
  const allowedResponse = await worker.fetch(
    new Request('https://coffeeindex.dpdns.org/supabase/auth/v1/otp', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({ email: 'invited@example.com' })
    }),
    { ASSETS: { fetch: () => new Response('asset') } }
  );
  assert.equal(allowedResponse.status, 200);
  assert.equal(upstreamRequests.length, 2);
  assert.equal(upstreamRequests[1].url, 'https://your_project_ref.supabase.co/auth/v1/otp');
  assert.equal(await upstreamRequests[1].clone().json().then(body => body.email), 'invited@example.com');

  upstreamRequests = [];
  const rejectedEmergencyResponse = await worker.fetch(
    new Request('https://coffeeindex.dpdns.org/emergency-access', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ code: 'wrong-code' })
    }),
    { EMERGENCY_ACCESS_CODE: 'correct-code', SUPABASE_SERVICE_ROLE_KEY: 'server-test-key', ASSETS: { fetch: () => new Response('asset') } }
  );
  assert.equal(rejectedEmergencyResponse.status, 401);
  assert.equal(upstreamRequests.length, 0);

  const emergencyResponse = await worker.fetch(
    new Request('https://coffeeindex.dpdns.org/emergency-access', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ code: 'correct-code' })
    }),
    { EMERGENCY_ACCESS_CODE: 'correct-code', SUPABASE_SERVICE_ROLE_KEY: 'server-test-key', ASSETS: { fetch: () => new Response('asset') } }
  );
  assert.equal(emergencyResponse.status, 200);
  assert.equal((await emergencyResponse.json()).token_hash, 'test-token-hash');
  assert.equal(upstreamRequests.length, 2);
  assert.equal(upstreamRequests[0].headers.get('authorization'), 'Bearer server-test-key');
  assert.equal(await upstreamRequests[1].clone().json().then(body => body.email), 'owner@example.com');

  console.log('Worker proxy tests passed.');
} finally {
  globalThis.fetch = originalFetch;
}
