const SUPABASE_ORIGIN = 'https://YOUR_PROJECT_REF.supabase.co';
const SUPABASE_PREFIX = '/supabase';
const ALLOWED_SUPABASE_PATHS = [
  '/auth/v1/',
  '/rest/v1/',
  '/realtime/v1/',
  '/storage/v1/'
];

function isAllowedSupabasePath(pathname) {
  return ALLOWED_SUPABASE_PATHS.some(prefix => pathname.startsWith(prefix));
}

function jsonResponse(body, status) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}

function constantTimeEquals(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string') return false;
  const length = Math.max(left.length, right.length);
  let difference = left.length ^ right.length;
  for (let index = 0; index < length; index += 1) {
    difference |= (left.charCodeAt(index) || 0) ^ (right.charCodeAt(index) || 0);
  }
  return difference === 0;
}

function adminHeaders(env) {
  const key = env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error('Missing server credential');
  return {
    apikey: key,
    authorization: `Bearer ${key}`,
    'content-type': 'application/json'
  };
}

async function createEmergencyLoginToken(env) {
  const headers = adminHeaders(env);
  const ownerResponse = await fetch(`${SUPABASE_ORIGIN}/rest/v1/profiles?role=eq.owner&select=email&limit=1`, { headers });
  if (!ownerResponse.ok) throw new Error('Owner lookup failed');
  const [owner] = await ownerResponse.json();
  if (!owner?.email) throw new Error('Owner not found');

  const linkResponse = await fetch(`${SUPABASE_ORIGIN}/auth/v1/admin/generate_link`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ type: 'magiclink', email: owner.email })
  });
  if (!linkResponse.ok) throw new Error('Emergency link generation failed');
  const generated = await linkResponse.json();
  // Supabase has returned this response both as { properties: { hashed_token } }
  // and { hashed_token } across Auth API versions.
  const tokenHash = generated.properties?.hashed_token || generated.hashed_token;
  if (!tokenHash) throw new Error('Emergency token missing');
  return tokenHash;
}

async function handleEmergencyAccess(request, env) {
  if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  let code;
  try {
    code = (await request.json()).code;
  } catch {
    return jsonResponse({ code: 'invalid_emergency_code' }, 401);
  }

  if (!constantTimeEquals(code, env.EMERGENCY_ACCESS_CODE || '')) {
    return jsonResponse({ code: 'invalid_emergency_code' }, 401);
  }

  try {
    const tokenHash = await createEmergencyLoginToken(env);
    return jsonResponse({ token_hash: tokenHash }, 200);
  } catch (error) {
    console.error('Emergency access token generation failed:', error instanceof Error ? error.message : String(error));
    return jsonResponse({ code: 'emergency_access_unavailable' }, 503);
  }
}

async function canRequestMagicLink(email, requestHeaders) {
  const headers = new Headers({ 'content-type': 'application/json' });
  const apiKey = requestHeaders.get('apikey');
  const authorization = requestHeaders.get('authorization');
  if (apiKey) headers.set('apikey', apiKey);
  if (authorization) headers.set('authorization', authorization);

  const response = await fetch(`${SUPABASE_ORIGIN}/rest/v1/rpc/can_request_magic_link`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ p_email: email })
  });
  if (!response.ok) throw new Error(`Invitation check failed with ${response.status}`);
  return response.json();
}

async function proxySupabase(request, incomingUrl) {
  const upstreamPath = incomingUrl.pathname.slice(SUPABASE_PREFIX.length) || '/';
  if (!isAllowedSupabasePath(upstreamPath)) {
    return new Response('Not found', { status: 404 });
  }

  const upstreamUrl = new URL(`${upstreamPath}${incomingUrl.search}`, SUPABASE_ORIGIN);
  const upstreamHeaders = new Headers(request.headers);
  upstreamHeaders.delete('host');
  upstreamHeaders.delete('cf-connecting-ip');
  upstreamHeaders.delete('cf-ipcountry');
  upstreamHeaders.delete('cf-ray');
  upstreamHeaders.delete('cf-visitor');

  const body = request.method === 'GET' || request.method === 'HEAD'
    ? undefined
    : await request.arrayBuffer();

  // Enforce invitation-only email login at the server boundary as well as in
  // the UI. This prevents direct calls to the public Auth endpoint from sending
  // mail to addresses that the owner has not invited.
  if (request.method === 'POST' && upstreamPath === '/auth/v1/otp') {
    let email;
    try {
      email = JSON.parse(new TextDecoder().decode(body)).email;
    } catch {
      return jsonResponse({ code: 'invalid_request', message: '邮箱格式无效。' }, 400);
    }

    try {
      if (!email || !(await canRequestMagicLink(email, request.headers))) {
        return jsonResponse({
          code: 'email_not_invited',
          message: '该邮箱尚未受邀请，未发送登录邮件。'
        }, 403);
      }
    } catch {
      return jsonResponse({
        code: 'invitation_check_unavailable',
        message: '暂时无法验证邀请状态，请稍后重试。'
      }, 503);
    }
  }

  const upstreamRequest = new Request(upstreamUrl, {
    method: request.method,
    headers: upstreamHeaders,
    body,
    redirect: 'manual'
  });
  const upstreamResponse = await fetch(upstreamRequest);
  const responseHeaders = new Headers(upstreamResponse.headers);
  responseHeaders.delete('access-control-allow-origin');
  responseHeaders.delete('access-control-allow-credentials');
  responseHeaders.set('cache-control', 'no-store');

  const location = responseHeaders.get('location');
  if (location?.startsWith(SUPABASE_ORIGIN)) {
    responseHeaders.set('location', location.replace(SUPABASE_ORIGIN, `${incomingUrl.origin}${SUPABASE_PREFIX}`));
  }

  return new Response(upstreamResponse.body, {
    status: upstreamResponse.status,
    statusText: upstreamResponse.statusText,
    headers: responseHeaders
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/emergency-access') {
      return handleEmergencyAccess(request, env);
    }
    if (url.pathname === SUPABASE_PREFIX || url.pathname.startsWith(`${SUPABASE_PREFIX}/`)) {
      return proxySupabase(request, url);
    }
    return env.ASSETS.fetch(request);
  }
};
