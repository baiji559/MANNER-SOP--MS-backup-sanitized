param(
  [string]$SdkRoot = "$PSScriptRoot\..\android-build-tools\android-sdk"
)

$ErrorActionPreference = 'Stop'

$projectRoot = $PSScriptRoot
$buildRoot = Join-Path $projectRoot 'build'
$resourcesDir = Join-Path $projectRoot 'app\src\main\res'
$manifest = Join-Path $projectRoot 'app\src\main\AndroidManifest.xml'
$sourceDir = Join-Path $projectRoot 'app\src\main\java'
$androidJar = Join-Path $SdkRoot 'platforms\android-35\android.jar'
$buildTools = Join-Path $SdkRoot 'build-tools\35.0.0'
$aapt = Join-Path $buildTools 'aapt.exe'
$aapt2 = Join-Path $buildTools 'aapt2.exe'
$d8 = Join-Path $buildTools 'd8.bat'
$zipalign = Join-Path $buildTools 'zipalign.exe'
$apksigner = Join-Path $buildTools 'apksigner.bat'
$debugKeystore = Join-Path $projectRoot 'debug.keystore'

foreach ($requiredPath in @($androidJar, $aapt, $aapt2, $d8, $zipalign, $apksigner, $manifest)) {
  if (-not (Test-Path $requiredPath)) { throw "Missing build dependency: $requiredPath" }
}

Remove-Item -LiteralPath $buildRoot -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $buildRoot, "$buildRoot\generated", "$buildRoot\classes", "$buildRoot\dex", "$buildRoot\outputs" | Out-Null

$compiledResources = Join-Path $buildRoot 'resources.zip'
$unsignedApk = Join-Path $buildRoot 'unsigned.apk'
$alignedApk = Join-Path $buildRoot 'aligned.apk'
$outputApk = Join-Path $buildRoot 'outputs\CoffeeIndex-1.0.7.apk'

& $aapt2 compile --dir $resourcesDir -o $compiledResources
if ($LASTEXITCODE -ne 0) { throw 'Resource compilation failed.' }
& $aapt2 link -I $androidJar --manifest $manifest --java "$buildRoot\generated" -o $unsignedApk $compiledResources
if ($LASTEXITCODE -ne 0) { throw 'Resource linking failed.' }

$javaSources = @(
  Get-ChildItem -LiteralPath $sourceDir -Recurse -Filter '*.java' | Select-Object -ExpandProperty FullName
) + @(
  Get-ChildItem -LiteralPath "$buildRoot\generated" -Recurse -Filter '*.java' | Select-Object -ExpandProperty FullName
)

& javac -encoding UTF-8 -source 17 -target 17 -classpath $androidJar -d "$buildRoot\classes" $javaSources
if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed.' }
$classFiles = Get-ChildItem -LiteralPath "$buildRoot\classes" -Recurse -Filter '*.class' | Select-Object -ExpandProperty FullName
& $d8 --min-api 24 --lib $androidJar --output "$buildRoot\dex" $classFiles
if ($LASTEXITCODE -ne 0) { throw 'DEX compilation failed.' }
& $aapt add -k $unsignedApk "$buildRoot\dex\classes.dex"
if ($LASTEXITCODE -ne 0) { throw 'Adding classes.dex failed.' }
& $zipalign -f -p 4 $unsignedApk $alignedApk
if ($LASTEXITCODE -ne 0) { throw 'APK alignment failed.' }

if (-not (Test-Path $debugKeystore)) {
  $keystoreSource = Join-Path $projectRoot 'tools\CreateKeystore.java'
  $keystoreClasses = Join-Path $buildRoot 'keystore-classes'
  New-Item -ItemType Directory -Force $keystoreClasses | Out-Null
  & javac --add-exports java.base/sun.security.x509=ALL-UNNAMED -d $keystoreClasses $keystoreSource
  if ($LASTEXITCODE -ne 0) { throw 'Debug signing-key compiler failed.' }
  & java --add-exports java.base/sun.security.x509=ALL-UNNAMED -cp $keystoreClasses CreateKeystore $debugKeystore
  if ($LASTEXITCODE -ne 0) { throw 'Debug signing-key generation failed.' }
}

& $apksigner sign --ks $debugKeystore --ks-type PKCS12 --ks-pass 'pass:android' --ks-key-alias androiddebugkey --key-pass 'pass:android' --min-sdk-version 1 --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true --out $outputApk $alignedApk
& $apksigner verify --verbose --min-sdk-version 1 $outputApk
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }

$fingerprint = (& $apksigner verify --print-certs $outputApk | Select-String 'Signer #1 certificate SHA-256 digest:' | Select-Object -First 1).ToString().Split(':')[-1].Trim()
$hash = (Get-FileHash -LiteralPath $outputApk -Algorithm SHA256).Hash

Write-Output "APK=$outputApk"
Write-Output "CERT_SHA256=$fingerprint"
Write-Output "APK_SHA256=$hash"
