import java.io.FileOutputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.util.Date;
import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateAlgorithmId;
import sun.security.x509.CertificateSerialNumber;
import sun.security.x509.CertificateValidity;
import sun.security.x509.CertificateVersion;
import sun.security.x509.CertificateX509Key;
import sun.security.x509.X500Name;
import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CertInfo;

public final class CreateKeystore {
  private static final char[] PASSWORD = "android".toCharArray();

  public static void main(String[] args) throws Exception {
    if (args.length != 1) throw new IllegalArgumentException("Expected output keystore path");
    KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
    generator.initialize(2048);
    KeyPair pair = generator.generateKeyPair();
    Date start = new Date();
    Date end = new Date(start.getTime() + 10_000L * 24 * 60 * 60 * 1000);
    X500Name owner = new X500Name("CN=Coffee Index Debug, O=Coffee Index, C=CN");
    X509CertInfo info = new X509CertInfo();
    info.set(X509CertInfo.VERSION, new CertificateVersion(CertificateVersion.V3));
    info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(new BigInteger(64, new SecureRandom())));
    info.set(X509CertInfo.SUBJECT, owner);
    info.set(X509CertInfo.ISSUER, owner);
    info.set(X509CertInfo.VALIDITY, new CertificateValidity(start, end));
    info.set(X509CertInfo.KEY, new CertificateX509Key(pair.getPublic()));
    info.set(X509CertInfo.ALGORITHM_ID, new CertificateAlgorithmId(AlgorithmId.get("SHA256withRSA")));

    X509CertImpl certificate = new X509CertImpl(info);
    certificate.sign(pair.getPrivate(), "SHA256withRSA");
    info.set(CertificateAlgorithmId.NAME + "." + CertificateAlgorithmId.ALGORITHM, certificate.get(X509CertImpl.SIG_ALG));
    certificate = new X509CertImpl(info);
    certificate.sign(pair.getPrivate(), "SHA256withRSA");

    KeyStore keyStore = KeyStore.getInstance("PKCS12");
    keyStore.load(null, PASSWORD);
    keyStore.setKeyEntry("androiddebugkey", pair.getPrivate(), PASSWORD, new Certificate[] { certificate });
    Path output = Path.of(args[0]);
    Files.createDirectories(output.getParent());
    try (FileOutputStream stream = new FileOutputStream(output.toFile())) {
      keyStore.store(stream, PASSWORD);
    }
  }
}
