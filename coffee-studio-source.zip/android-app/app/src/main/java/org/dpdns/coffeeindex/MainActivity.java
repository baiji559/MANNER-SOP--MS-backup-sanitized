package org.dpdns.coffeeindex;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private static final String APP_HOST = "coffeeindex.dpdns.org";
  private static final String APP_SCHEME = "coffeeindex";
  private static final String APP_CALLBACK_HOST = "auth";
  private static final String HOME_URL = "https://coffeeindex.dpdns.org/?native=android&v=107";
  private WebView webView;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(242, 239, 231));
    getWindow().setNavigationBarColor(Color.rgb(242, 239, 231));
    int systemUiFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      systemUiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
    }
    getWindow().getDecorView().setSystemUiVisibility(systemUiFlags);

    webView = new WebView(this);
    webView.setBackgroundColor(Color.rgb(242, 239, 231));
    // Android 15 draws edge-to-edge by default for apps targeting API 35.
    // Keep the WebView content below the status icons instead of letting the
    // website's toolbar render behind them.
    webView.setOnApplyWindowInsetsListener((view, insets) -> {
      view.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
      return insets;
    });
    setContentView(webView);
    webView.requestApplyInsets();

    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);
    settings.setCacheMode(WebSettings.LOAD_DEFAULT);
    settings.setLoadWithOverviewMode(true);
    settings.setUseWideViewPort(true);
    settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setUserAgentString(settings.getUserAgentString() + " CoffeeIndexAndroid/1.0");

    CookieManager cookies = CookieManager.getInstance();
    cookies.setAcceptCookie(true);
    cookies.setAcceptThirdPartyCookies(webView, true);

    webView.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return loadOrOpenExternal(request.getUrl());
      }

      @Override
      @SuppressWarnings("deprecation")
      public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return loadOrOpenExternal(Uri.parse(url));
      }

      @Override
      public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        if (request.isForMainFrame()) showLoadError();
      }
    });

    openIncomingLink(getIntent());
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    openIncomingLink(intent);
  }

  private void openIncomingLink(Intent intent) {
    Uri link = intent == null ? null : intent.getData();
    if (isCoffeeIndexLink(link)) {
      webView.loadUrl(link.toString());
      return;
    }
    if (isAppCallback(link)) {
      String query = link.getEncodedQuery();
      String fragment = link.getEncodedFragment();
      // A fragment-only load on an already-open WebView is same-document and
      // does not rerun the page's auth bootstrap. Force a fresh navigation.
      String callbackUrl = HOME_URL + "&login_return=" + System.currentTimeMillis();
      if (query != null && !query.isEmpty()) callbackUrl += "&" + query;
      if (fragment != null && !fragment.isEmpty()) callbackUrl += "#" + fragment;
      webView.loadUrl(callbackUrl);
      return;
    }
    webView.loadUrl(HOME_URL);
  }

  private boolean loadOrOpenExternal(Uri link) {
    if (isCoffeeIndexLink(link)) {
      webView.loadUrl(link.toString());
      return true;
    }

    try {
      startActivity(new Intent(Intent.ACTION_VIEW, link));
    } catch (Exception ignored) {
      // If the device has no compatible app for an external URL, stay in place.
    }
    return true;
  }

  private boolean isCoffeeIndexLink(Uri link) {
    return link != null
      && "https".equalsIgnoreCase(link.getScheme())
      && APP_HOST.equalsIgnoreCase(link.getHost());
  }

  private boolean isAppCallback(Uri link) {
    return link != null
      && APP_SCHEME.equalsIgnoreCase(link.getScheme())
      && APP_CALLBACK_HOST.equalsIgnoreCase(link.getHost())
      && "/callback".equals(link.getPath());
  }

  private void showLoadError() {
    String html = "<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'>"
      + "<body style='margin:0;padding:56px 24px;background:#f2efe7;color:#161411;font-family:sans-serif'>"
      + "<p style='color:#d7472f;font-size:12px;font-weight:700'>CONNECTION</p>"
      + "<h1 style='font-size:40px;line-height:1.05'>页面暂时没有加载出来。</h1>"
      + "<p style='line-height:1.7;color:#726d64'>请检查网络后重新加载。</p>"
      + "<a href='" + HOME_URL + "' style='display:block;margin-top:28px;padding:16px;background:#161411;color:white;text-decoration:none;text-align:center'>重新加载</a>"
      + "</body></html>";
    webView.loadDataWithBaseURL(HOME_URL, html, "text/html", "UTF-8", null);
  }

  @Override
  @SuppressWarnings("deprecation")
  public void onBackPressed() {
    if (webView.canGoBack()) {
      webView.goBack();
    } else {
      super.onBackPressed();
    }
  }
}
