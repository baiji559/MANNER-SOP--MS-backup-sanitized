package org.dpdns.coffeeindex;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private static final String APP_HOST = "coffeeindex.dpdns.org";
  private static final String APP_SCHEME = "coffeeindex";
  private static final String APP_CALLBACK_HOST = "auth";
  private static final String HOME_URL = "https://coffeeindex.dpdns.org/";
  private WebView webView;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(242, 239, 231));
    getWindow().setNavigationBarColor(Color.rgb(242, 239, 231));
    int systemUiFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      systemUiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
    }
    getWindow().getDecorView().setSystemUiVisibility(systemUiFlags);

    webView = new WebView(this);
    webView.setBackgroundColor(Color.rgb(242, 239, 231));
    // Android 15 draws edge-to-edge by default for apps targeting API 35.
    // Keep the WebView content below the status icons instead of letting the
    // website's toolbar render behind them.
    webView.setOnApplyWindowInsetsListener((view, insets) -> {
      view.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
      return insets;
    });
    setContentView(webView);
    webView.requestApplyInsets();

    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);
    settings.setLoadWithOverviewMode(true);
    settings.setUseWideViewPort(true);
    settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setUserAgentString(settings.getUserAgentString() + " CoffeeIndexAndroid/1.0");

    CookieManager cookies = CookieManager.getInstance();
    cookies.setAcceptCookie(true);
    cookies.setAcceptThirdPartyCookies(webView, true);

    webView.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return loadOrOpenExternal(request.getUrl());
      }

      @Override
      @SuppressWarnings("deprecation")
      public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return loadOrOpenExternal(Uri.parse(url));
      }
    });

    openIncomingLink(getIntent());
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    openIncomingLink(intent);
  }

  private void openIncomingLink(Intent intent) {
    Uri link = intent == null ? null : intent.getData();
    if (isCoffeeIndexLink(link)) {
      webView.loadUrl(link.toString());
      return;
    }
    if (isAppCallback(link)) {
      String query = link.getEncodedQuery();
      String fragment = link.getEncodedFragment();
      String suffix = (query == null || query.isEmpty()) ? "" : "?" + query;
      if (fragment != null && !fragment.isEmpty()) suffix += "#" + fragment;
      webView.loadUrl(HOME_URL + suffix);
      return;
    }
    webView.loadUrl(HOME_URL);
  }

  private boolean loadOrOpenExternal(Uri link) {
    if (isCoffeeIndexLink(link)) {
      webView.loadUrl(link.toString());
      return true;
    }

    try {
      startActivity(new Intent(Intent.ACTION_VIEW, link));
    } catch (Exception ignored) {
      // If the device has no compatible app for an external URL, stay in place.
    }
    return true;
  }

  private boolean isCoffeeIndexLink(Uri link) {
    return link != null
      && "https".equalsIgnoreCase(link.getScheme())
      && APP_HOST.equalsIgnoreCase(link.getHost());
  }

  private boolean isAppCallback(Uri link) {
    return link != null
      && APP_SCHEME.equalsIgnoreCase(link.getScheme())
      && APP_CALLBACK_HOST.equalsIgnoreCase(link.getHost())
      && "/callback".equals(link.getPath());
  }

  @Override
  @SuppressWarnings("deprecation")
  public void onBackPressed() {
    if (webView.canGoBack()) {
      webView.goBack();
    } else {
      super.onBackPressed();
    }
  }
}
