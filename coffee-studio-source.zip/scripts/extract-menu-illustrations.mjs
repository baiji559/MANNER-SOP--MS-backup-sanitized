import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';

const [sourcePath, outputDirectory] = process.argv.slice(2);

if (!sourcePath || !outputDirectory) {
  throw new Error('Usage: node scripts/extract-menu-illustrations.mjs <source.html> <output-directory>');
}

const html = await readFile(sourcePath, 'utf8');
const illustrations = [...html.matchAll(/<svg\b[\s\S]*?<\/svg>/gi)].map(match => match[0]);

if (!illustrations.length) throw new Error(`No inline SVG illustrations found in ${basename(sourcePath)}`);

const unsafePattern = /<script\b|<foreignObject\b|<image\b|\son[a-z]+\s*=|(?:href|xlink:href)\s*=\s*["']\s*(?!#)/i;
const unsafeIndex = illustrations.findIndex(svg => unsafePattern.test(svg));
if (unsafeIndex >= 0) throw new Error(`Unsafe SVG content found at illustration ${unsafeIndex}`);

await mkdir(outputDirectory, { recursive: true });

for (const [index, svg] of illustrations.entries()) {
  const fileName = `menu-drink-${String(index).padStart(2, '0')}-v1.svg`;
  await writeFile(join(outputDirectory, fileName), `${svg}\n`, 'utf8');
}

console.log(`Extracted ${illustrations.length} safe SVG illustrations to ${outputDirectory}`);
