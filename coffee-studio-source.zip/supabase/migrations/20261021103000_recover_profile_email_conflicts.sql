-- A magic-link user can be recreated in Auth while retaining the same email.
-- Keep the invite/profile model email-address based, while re-linking the
-- public profile to the newly authenticated Auth user when that happens.

alter table public.member_invites
  drop constraint if exists member_invites_invited_by_fkey;

alter table public.member_invites
  add constraint member_invites_invited_by_fkey
  foreign key (invited_by) references public.profiles(id)
  on delete set null
  on update cascade;

alter table public.recipes
  drop constraint if exists recipes_updated_by_fkey;

alter table public.recipes
  add constraint recipes_updated_by_fkey
  foreign key (updated_by) references public.profiles(id)
  on delete set null
  on update cascade;

create or replace function public.initialize_current_profile()
returns public.profiles
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_email text;
  v_role text;
  v_profile public.profiles;
begin
  if auth.uid() is null then
    raise exception 'Authentication is required';
  end if;

  select lower(email) into v_email
  from auth.users
  where id = auth.uid();

  if v_email is null then
    raise exception 'A verified email address is required';
  end if;

  -- An existing owner keeps the owner role even though owners are not invites.
  select role into v_role
  from public.profiles
  where email = v_email;

  if v_role is distinct from 'owner' then
    if v_email = 'owner@example.invalid'
       and not exists (select 1 from public.profiles where role = 'owner') then
      v_role := 'owner';
    else
      select role into v_role
      from public.member_invites
      where email = v_email;
    end if;
  end if;

  if v_role is null then
    raise exception 'This email has not been invited to this recipe library';
  end if;

  -- Conflict on email means this verified address was linked to an old Auth
  -- UUID. Move the profile (and cascading audit references) to this UUID.
  insert into public.profiles (id, email, role)
  values (auth.uid(), v_email, v_role)
  on conflict (email) do update
  set id = excluded.id,
      role = excluded.role
  returning * into v_profile;

  return v_profile;
end;
$$;
