-- Only an existing member or an Owner-managed invitation may request a magic link.
-- This function deliberately returns a boolean only: no invitation, role, or member
-- details are exposed to the browser.
create or replace function public.can_request_magic_link(p_email text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $function$
  with normalized as (
    select lower(trim(coalesce(p_email, ''))) as email
  )
  select
    normalized.email ~ '^[^@[:space:]]+@[^@[:space:]]+\\.[^@[:space:]]+$'
    and (
      exists (select 1 from public.profiles where email = normalized.email)
      or exists (select 1 from public.member_invites where email = normalized.email)
      or (
        normalized.email = 'owner@example.invalid'
        and not exists (select 1 from public.profiles where role = 'owner')
      )
    )
  from normalized;
$function$;

revoke all on function public.can_request_magic_link(text) from public;
grant usage on schema public to anon, authenticated;
grant execute on function public.can_request_magic_link(text) to anon, authenticated;
