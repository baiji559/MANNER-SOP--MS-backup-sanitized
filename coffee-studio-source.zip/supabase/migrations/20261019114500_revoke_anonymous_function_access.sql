-- Functions that authorize membership must never be callable before sign-in.
revoke all on function public.is_owner() from anon;
revoke all on function public.can_edit_recipes() from anon;
revoke all on function public.initialize_current_profile() from anon;
revoke all on function public.invite_member(text, text) from anon;
revoke all on function public.remove_member(text) from anon;

revoke all on function public.is_owner() from public;
revoke all on function public.can_edit_recipes() from public;
revoke all on function public.initialize_current_profile() from public;
revoke all on function public.invite_member(text, text) from public;
revoke all on function public.remove_member(text) from public;

grant execute on function public.is_owner(), public.can_edit_recipes(), public.initialize_current_profile(), public.invite_member(text, text), public.remove_member(text) to authenticated;
