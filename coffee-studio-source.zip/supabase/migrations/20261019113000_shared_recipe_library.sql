-- Shared MANNER recipe library: authenticated, invite-only readers and owner-managed editors.

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique check (email = lower(email)),
  role text not null check (role in ('owner', 'admin', 'viewer')),
  created_at timestamptz not null default now()
);

create table public.member_invites (
  email text primary key check (email = lower(email)),
  role text not null check (role in ('admin', 'viewer')),
  invited_at timestamptz not null default now(),
  invited_by uuid references public.profiles(id) on delete set null
);

create table public.recipes (
  id text primary key,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles(id) on delete set null
);

create index recipes_sort_order_idx on public.recipes (sort_order, id);

alter table public.profiles enable row level security;
alter table public.member_invites enable row level security;
alter table public.recipes enable row level security;

create function public.is_owner()
returns boolean
language sql
stable
security definer
set search_path = public, auth
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'owner'
  );
$$;

create function public.can_edit_recipes()
returns boolean
language sql
stable
security definer
set search_path = public, auth
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role in ('owner', 'admin')
  );
$$;

create function public.initialize_current_profile()
returns public.profiles
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_email text;
  v_role text;
  v_profile public.profiles;
begin
  if auth.uid() is null then
    raise exception 'Authentication is required';
  end if;

  select lower(email) into v_email
  from auth.users
  where id = auth.uid();

  if v_email is null then
    raise exception 'A verified email address is required';
  end if;

  if v_email = 'owner@example.invalid'
     and not exists (select 1 from public.profiles where role = 'owner') then
    v_role := 'owner';
  else
    select role into v_role from public.member_invites where email = v_email;
  end if;

  if v_role is null then
    raise exception 'This email has not been invited to this recipe library';
  end if;

  insert into public.profiles (id, email, role)
  values (auth.uid(), v_email, v_role)
  on conflict (id) do nothing;

  select * into v_profile from public.profiles where id = auth.uid();
  return v_profile;
end;
$$;

create function public.invite_member(p_email text, p_role text default 'viewer')
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_email text := lower(trim(p_email));
begin
  if not public.is_owner() then
    raise exception 'Only the owner can manage members';
  end if;
  if position('@' in v_email) < 2 then
    raise exception 'Enter a valid email address';
  end if;
  if p_role not in ('admin', 'viewer') then
    raise exception 'Member role must be admin or viewer';
  end if;

  insert into public.member_invites (email, role, invited_by)
  values (v_email, p_role, auth.uid())
  on conflict (email) do update
  set role = excluded.role, invited_at = now(), invited_by = excluded.invited_by;

  update public.profiles
  set role = p_role
  where email = v_email and role <> 'owner';
end;
$$;

create function public.remove_member(p_email text)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_email text := lower(trim(p_email));
begin
  if not public.is_owner() then
    raise exception 'Only the owner can manage members';
  end if;
  delete from public.member_invites where email = v_email;
  delete from public.profiles where email = v_email and role <> 'owner';
end;
$$;

create function public.set_recipe_metadata()
returns trigger
language plpgsql
set search_path = public, auth
as $$
begin
  new.updated_at := now();
  new.updated_by := auth.uid();
  return new;
end;
$$;

create trigger recipes_set_metadata
before insert or update on public.recipes
for each row execute function public.set_recipe_metadata();

create policy "Members can see their own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.is_owner()));

create policy "Owner can see invitations"
on public.member_invites for select to authenticated
using ((select public.is_owner()));

create policy "Invited members can read recipes"
on public.recipes for select to authenticated
using (exists (select 1 from public.profiles where id = (select auth.uid())));

create policy "Editors can add recipes"
on public.recipes for insert to authenticated
with check ((select public.can_edit_recipes()));

create policy "Editors can update recipes"
on public.recipes for update to authenticated
using ((select public.can_edit_recipes()))
with check ((select public.can_edit_recipes()));

create policy "Editors can remove recipes"
on public.recipes for delete to authenticated
using ((select public.can_edit_recipes()));

grant usage on schema public to authenticated;
grant select on public.profiles, public.member_invites, public.recipes to authenticated;
grant insert, update, delete on public.recipes to authenticated;

revoke all on function public.is_owner() from public;
revoke all on function public.can_edit_recipes() from public;
revoke all on function public.initialize_current_profile() from public;
revoke all on function public.invite_member(text, text) from public;
revoke all on function public.remove_member(text) from public;
grant execute on function public.is_owner(), public.can_edit_recipes(), public.initialize_current_profile(), public.invite_member(text, text), public.remove_member(text) to authenticated;

alter publication supabase_realtime add table public.recipes;
