# Coffee Index: Cloudflare Pages migration

Status: upload package prepared; independent deployment and domain cutover NOT completed.

Source: `../coffee-studio/dist` from the sanitized backup.
Package: `coffeeindex-cloudflare.zip`, containing only index.html, styles.css and app.js.
Rebuild with `./prepare-cloudflare.ps1` after choosing a fresh output filename.

The original Sites deployment and DNS remain unchanged.
The existing Supabase project remains the backend; no database import/reset is needed.
No SMTP key or server-side API credential is included.

## Deployment order

1. In the owner's Cloudflare account, create a Pages Direct Upload project.
2. Upload the ZIP; use `coffeeindex` as the preferred project name if available.
3. Record the actual pages.dev URL returned by Cloudflare. Do not assume a hostname.
4. Verify that the new deployment serves the app and its local assets.
5. Add coffeeindex.dpdns.org in that Pages project's Custom domains section.
6. If the existing Sites binding conflicts, remove only that custom-domain binding,
   retaining the original Sites project and its chatgpt.site address.
7. Replace only the two old apex A records (162.159.143.30 and 172.66.3.26)
   with the DNS record required by the verified Pages project. Keep other records.
8. Verify custom-domain HTTPS and page access before testing sign-in.
9. Verify the auth redirect allowlist includes https://coffeeindex.dpdns.org/.
   Retain the old site URL as an allowed redirect for rollback.
10. Test Owner login and invited-member access from the new domain.

## Notes

- The bundle retains the original app unchanged, including its CDN-loaded client
  library and embedded seed recipes. The login overlay does not make bundled
  seed data confidential; server access controls protect cloud data operations.
- Browser-local favorites and login sessions do not transfer between origins.
- A successful deployment does not guarantee access from every network.
- Do not point DNS at an assumed pages.dev hostname.
- Direct Upload can be updated by subsequent uploads or Wrangler; switching the
  same project to Git integration is not supported.

Reference: https://developers.cloudflare.com/pages/get-started/direct-upload/
