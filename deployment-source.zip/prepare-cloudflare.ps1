$ErrorActionPreference = 'Stop'

# Package only the public web assets. Never include .git, hosting metadata,
# database migrations, credentials, or unrelated workspace files.
$sourceDirectory = Join-Path (Split-Path $PSScriptRoot -Parent) 'coffee-studio/dist'
$archivePath = Join-Path $PSScriptRoot 'coffeeindex-cloudflare.zip'
$assetNames = @('index.html', 'styles.css', 'app.js')
$assetPaths = @($assetNames | ForEach-Object { Join-Path $sourceDirectory $_ })

foreach ($assetPath in $assetPaths) {
    if (-not (Test-Path -LiteralPath $assetPath -PathType Leaf)) {
        throw "Missing public asset: $assetPath"
    }
}
if (Test-Path -LiteralPath $archivePath) {
    throw "Archive already exists; preserve it and choose a new output filename."
}

& node --check (Join-Path $sourceDirectory 'app.js')
if ($LASTEXITCODE -ne 0) { throw 'JavaScript syntax validation failed.' }

$html = Get-Content -LiteralPath (Join-Path $sourceDirectory 'index.html') -Raw
foreach ($assetName in @('styles.css', 'app.js')) {
    if (-not $html.Contains("./$assetName")) {
        throw "Expected relative asset reference is missing: $assetName"
    }
}
foreach ($assetPath in $assetPaths) {
    $text = Get-Content -LiteralPath $assetPath -Raw
    if ($text -match 'sb_secret_|service_role|SUPABASE_SERVICE_ROLE_KEY|CLOUDFLARE_API_TOKEN') {
        throw "Possible server credential in public asset: $assetPath"
    }
}

Compress-Archive -LiteralPath $assetPaths -DestinationPath $archivePath
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    $actualNames = @($archive.Entries | ForEach-Object { $_.FullName } | Sort-Object)
    if (($actualNames -join ',') -ne (($assetNames | Sort-Object) -join ',')) {
        throw 'Unexpected archive layout. index.html must be at the ZIP root.'
    }
    foreach ($entry in $archive.Entries) {
        $stream = $entry.Open()
        $sha256 = [System.Security.Cryptography.SHA256]::Create()
        try {
            $archivedHash = [BitConverter]::ToString($sha256.ComputeHash($stream)).Replace('-', '')
            $sourceHash = (Get-FileHash -LiteralPath (Join-Path $sourceDirectory $entry.FullName) -Algorithm SHA256).Hash
            if ($archivedHash -ne $sourceHash) { throw "Archive content mismatch: $($entry.FullName)" }
        } finally {
            $sha256.Dispose()
            $stream.Dispose()
        }
    }
    $archive.Entries | Select-Object FullName, Length
} finally {
    $archive.Dispose()
}
Get-Item -LiteralPath $archivePath | Select-Object FullName, Length
Get-FileHash -LiteralPath $archivePath -Algorithm SHA256
